package com.salesProject.Sales.DAO;

public class SalesDAO {



}
