package com.salesProject.Sales.QueryConstants;

public class salesQyeryConsatnt {


}
