package com.salesProject.Sales.Repository;

public interface SalesRepository {
}
