package com.salesProject.Sales.QueryConstants;

public class Constant {

    public static String driver="com.mysql.jdbc.Driver";
    public static String url="jdbc:mysql://localhost:3306/shopping";
    public static String user="root";
    public static String password="root";
}
